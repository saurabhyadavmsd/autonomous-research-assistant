"""
config.py — Central configuration for the Autonomous Research Assistant.
Override values via environment variables or .env file.
"""

import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    # --- LLM Settings ---
    MODEL_NAME: str = os.getenv("MODEL_NAME", "gpt-4")
    TEMPERATURE: float = float(os.getenv("TEMPERATURE", "0.2"))
    MAX_TOKENS: int = int(os.getenv("MAX_TOKENS", "2000"))

    # --- Agent Settings ---
    MAX_PAPERS: int = int(os.getenv("MAX_PAPERS", "15"))
    MIN_RELEVANCE_SCORE: float = float(os.getenv("MIN_RELEVANCE_SCORE", "6.0"))
    SUMMARY_LENGTH: int = int(os.getenv("SUMMARY_LENGTH", "300"))  # words
    MAX_AGENT_ITERATIONS: int = int(os.getenv("MAX_AGENT_ITERATIONS", "10"))

    # --- API Keys ---
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    SERPAPI_KEY: str = os.getenv("SERPAPI_KEY", "")
    SEMANTIC_SCHOLAR_KEY: str = os.getenv("SEMANTIC_SCHOLAR_KEY", "")

    # --- Output Settings ---
    REPORT_FORMAT: str = os.getenv("REPORT_FORMAT", "md")  # "md" or "pdf"
    OUTPUT_DIR: str = os.getenv("OUTPUT_DIR", "outputs")

    # --- Vector Store ---
    FAISS_INDEX_PATH: str = os.getenv("FAISS_INDEX_PATH", ".faiss_index")
    EMBEDDING_MODEL: str = "text-embedding-ada-002"

    # --- arXiv Settings ---
    ARXIV_MAX_RESULTS: int = int(os.getenv("ARXIV_MAX_RESULTS", "20"))
    ARXIV_SORT_BY: str = "relevance"  # "relevance" | "lastUpdatedDate" | "submittedDate"

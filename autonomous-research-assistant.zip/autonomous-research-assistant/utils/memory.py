"""
utils/memory.py
FAISS-based vector store for agent memory across sessions.
Allows agents to retrieve semantically similar content from previous runs.
"""

import os
from typing import List, Dict, Optional

from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings
from langchain.docstore.document import Document
from config import Config


class VectorMemory:
    """
    Persistent vector store using FAISS + OpenAI embeddings.
    Used by agents to store and retrieve paper summaries semantically.
    """

    def __init__(self, index_path: str = Config.FAISS_INDEX_PATH):
        self.index_path = index_path
        self.embeddings = OpenAIEmbeddings(
            model=Config.EMBEDDING_MODEL,
            openai_api_key=Config.OPENAI_API_KEY,
        )
        self.vectorstore: Optional[FAISS] = None
        self._load_or_create()

    def _load_or_create(self):
        """Load existing FAISS index from disk, or create a new empty one."""
        if os.path.exists(self.index_path):
            try:
                self.vectorstore = FAISS.load_local(
                    self.index_path,
                    self.embeddings,
                    allow_dangerous_deserialization=True,
                )
                return
            except Exception:
                pass  # Fall through to create new

        # Bootstrap with a placeholder document
        placeholder = Document(
            page_content="Research assistant memory initialized.",
            metadata={"type": "system"},
        )
        self.vectorstore = FAISS.from_documents([placeholder], self.embeddings)

    def add(self, text: str, metadata: Dict = None):
        """Add a text chunk (e.g., paper summary) to the vector store."""
        doc = Document(page_content=text, metadata=metadata or {})
        self.vectorstore.add_documents([doc])

    def search(self, query: str, k: int = 5) -> List[Document]:
        """Semantic search over stored documents."""
        return self.vectorstore.similarity_search(query, k=k)

    def save(self):
        """Persist the FAISS index to disk."""
        self.vectorstore.save_local(self.index_path)

    def clear(self):
        """Reset the vector store (removes saved index)."""
        import shutil
        if os.path.exists(self.index_path):
            shutil.rmtree(self.index_path)
        self._load_or_create()

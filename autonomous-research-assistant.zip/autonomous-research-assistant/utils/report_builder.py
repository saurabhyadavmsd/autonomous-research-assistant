"""
utils/report_builder.py
Saves the generated report to disk in Markdown or PDF format.
"""

import os
import re
from datetime import datetime
from typing import Optional


class ReportBuilder:
    """Handles saving research reports to Markdown or PDF."""

    def __init__(self, topic: str, output_dir: str = "outputs"):
        self.topic = topic
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def _make_filename(self, fmt: str) -> str:
        """Generate a clean filename from the topic."""
        slug = re.sub(r"[^a-z0-9]+", "_", self.topic.lower()).strip("_")
        slug = slug[:50]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        return os.path.join(self.output_dir, f"{slug}_{timestamp}.{fmt}")

    def save(self, content: str, fmt: str = "md") -> str:
        """
        Save report content to file.

        Args:
            content: Markdown string of the report
            fmt: "md" for Markdown, "pdf" for PDF

        Returns:
            Path to saved file
        """
        if fmt == "pdf":
            return self._save_pdf(content)
        return self._save_markdown(content)

    def _save_markdown(self, content: str) -> str:
        path = self._make_filename("md")
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    def _save_pdf(self, content: str) -> str:
        """Convert Markdown to PDF using ReportLab."""
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            from reportlab.lib.units import inch
            from reportlab.lib import colors
        except ImportError:
            print("   [ReportBuilder] reportlab not installed. Saving as .md instead.")
            return self._save_markdown(content)

        path = self._make_filename("pdf")
        doc = SimpleDocTemplate(path, pagesize=letter,
                                rightMargin=inch, leftMargin=inch,
                                topMargin=inch, bottomMargin=inch)
        styles = getSampleStyleSheet()
        story = []

        for line in content.split("\n"):
            line = line.strip()
            if not line:
                story.append(Spacer(1, 0.15 * inch))
            elif line.startswith("# "):
                story.append(Paragraph(line[2:], styles["Title"]))
            elif line.startswith("## "):
                story.append(Paragraph(line[3:], styles["Heading1"]))
            elif line.startswith("### "):
                story.append(Paragraph(line[4:], styles["Heading2"]))
            else:
                # Strip basic markdown bold/italic for PDF
                line = re.sub(r"\*\*(.*?)\*\*", r"\1", line)
                line = re.sub(r"\*(.*?)\*", r"\1", line)
                story.append(Paragraph(line, styles["Normal"]))

        doc.build(story)
        return path

"""
agents/summarizer_agent.py
Uses an LLM chain to summarize individual papers into structured summaries.
"""

from langchain.chat_models import ChatOpenAI
from langchain.chains import LLMChain
from langchain.prompts import ChatPromptTemplate

from utils.prompts import SUMMARIZER_PROMPT
from config import Config


class SummarizerAgent:
    """
    Takes a paper dict (title + abstract or full text) and returns
    a structured summary: Background → Methods → Results → Limitations.
    """

    def __init__(self, llm: ChatOpenAI):
        self.llm = llm
        self.chain = LLMChain(
            llm=self.llm,
            prompt=ChatPromptTemplate.from_template(SUMMARIZER_PROMPT),
        )

    def summarize(self, paper: dict) -> str:
        """
        Summarize a single paper.

        Args:
            paper: dict with keys 'title', 'abstract', optionally 'full_text'

        Returns:
            Structured summary string
        """
        text = paper.get("full_text") or paper.get("abstract", "No content available.")
        title = paper.get("title", "Unknown Title")

        # Trim to avoid token overflow (approx 3000 words)
        words = text.split()
        if len(words) > 3000:
            text = " ".join(words[:3000]) + " [truncated]"

        result = self.chain.run(
            title=title,
            text=text,
            target_length=Config.SUMMARY_LENGTH,
        )
        return result.strip()

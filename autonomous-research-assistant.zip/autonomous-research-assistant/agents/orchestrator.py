"""
agents/orchestrator.py
Master agent that decomposes the research task and coordinates
the Search, Summarizer, Critic, and Report agents.
"""

from typing import List, Dict, Any
from langchain.chat_models import ChatOpenAI
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain.memory import ConversationBufferMemory
from langchain import hub

from agents.search_agent import SearchAgent
from agents.summarizer_agent import SummarizerAgent
from agents.critic_agent import CriticAgent
from agents.report_agent import ReportAgent
from utils.memory import VectorMemory
from utils.prompts import ORCHESTRATOR_SYSTEM_PROMPT
from config import Config


class OrchestratorAgent:
    """
    Master orchestrator that:
    1. Delegates paper retrieval to SearchAgent
    2. Sends papers to SummarizerAgent
    3. Sends summaries to CriticAgent for scoring
    4. Passes filtered summaries to ReportAgent
    """

    def __init__(self, topic: str, max_papers: int = Config.MAX_PAPERS):
        self.topic = topic
        self.max_papers = max_papers

        # Shared LLM
        self.llm = ChatOpenAI(
            model_name=Config.MODEL_NAME,
            temperature=Config.TEMPERATURE,
            openai_api_key=Config.OPENAI_API_KEY,
        )

        # Shared vector memory across agents
        self.memory = VectorMemory()

        # Sub-agents
        self.search_agent = SearchAgent(llm=self.llm, max_results=max_papers)
        self.summarizer_agent = SummarizerAgent(llm=self.llm)
        self.critic_agent = CriticAgent(llm=self.llm, topic=topic)
        self.report_agent = ReportAgent(llm=self.llm, topic=topic)

    def run_search(self) -> List[Dict[str, Any]]:
        """Retrieve papers relevant to the topic."""
        return self.search_agent.search(self.topic)

    def run_summarization(self, papers: List[Dict]) -> List[Dict]:
        """Summarize each paper and attach summary to its metadata."""
        summarized = []
        for i, paper in enumerate(papers, 1):
            print(f"   Summarizing [{i}/{len(papers)}]: {paper.get('title', 'Unknown')[:60]}...")
            summary = self.summarizer_agent.summarize(paper)
            paper["summary"] = summary
            # Store in vector memory for cross-agent context
            self.memory.add(
                text=summary,
                metadata={"title": paper.get("title"), "source": paper.get("url", "")}
            )
            summarized.append(paper)
        return summarized

    def run_critique(self, summaries: List[Dict]) -> List[Dict]:
        """Score each summary and filter low-relevance papers."""
        scored = self.critic_agent.score_all(summaries)
        filtered = [
            p for p in scored
            if p.get("relevance_score", 0) >= Config.MIN_RELEVANCE_SCORE
        ]
        print(f"   Filtered: {len(summaries) - len(filtered)} low-relevance papers removed")
        return filtered

    def run_report_generation(self, papers: List[Dict]) -> str:
        """Generate the final research report."""
        return self.report_agent.generate(papers)

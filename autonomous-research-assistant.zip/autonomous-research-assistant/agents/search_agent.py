"""
agents/search_agent.py
Searches arXiv and optionally the web for papers on the given topic.
"""

from typing import List, Dict, Any
from langchain.chat_models import ChatOpenAI
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain import hub

from tools.arxiv_tool import ArxivSearchTool
from tools.web_search import WebSearchTool
from utils.prompts import SEARCH_AGENT_PROMPT
from config import Config


class SearchAgent:
    """
    Retrieves relevant academic papers using:
    - arXiv API (primary source)
    - SerpAPI web search (fallback / supplemental)
    """

    def __init__(self, llm: ChatOpenAI, max_results: int = Config.MAX_PAPERS):
        self.llm = llm
        self.max_results = max_results
        self.arxiv_tool = ArxivSearchTool(max_results=max_results)
        self.web_tool = WebSearchTool()

    def search(self, topic: str) -> List[Dict[str, Any]]:
        """
        Run arXiv search. Falls back to web search if results < 3.
        Returns a list of paper dicts with keys:
          title, authors, abstract, url, published, source
        """
        papers = self.arxiv_tool.search(topic)

        if len(papers) < 3 and Config.SERPAPI_KEY:
            print("   arXiv returned few results, supplementing with web search...")
            web_results = self.web_tool.search(topic)
            papers.extend(web_results)

        # Deduplicate by title
        seen = set()
        unique_papers = []
        for p in papers:
            title = p.get("title", "").lower().strip()
            if title not in seen:
                seen.add(title)
                unique_papers.append(p)

        return unique_papers[: self.max_results]

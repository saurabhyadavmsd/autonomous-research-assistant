"""
agents/critic_agent.py
Scores each paper's relevance to the research topic on a 1-10 scale.
"""

import re
from typing import List, Dict
from langchain.chat_models import ChatOpenAI
from langchain.chains import LLMChain
from langchain.prompts import ChatPromptTemplate

from utils.prompts import CRITIC_PROMPT
from config import Config


class CriticAgent:
    """
    Evaluates relevance and quality of each summarized paper.
    Assigns a score 1-10; papers below MIN_RELEVANCE_SCORE are filtered out.
    """

    def __init__(self, llm: ChatOpenAI, topic: str):
        self.llm = llm
        self.topic = topic
        self.chain = LLMChain(
            llm=self.llm,
            prompt=ChatPromptTemplate.from_template(CRITIC_PROMPT),
        )

    def score(self, paper: dict) -> float:
        """
        Score a single paper.

        Returns:
            float between 1.0 and 10.0
        """
        response = self.chain.run(
            topic=self.topic,
            title=paper.get("title", "Unknown"),
            summary=paper.get("summary", "No summary available."),
        )

        # Parse score from response like "Score: 7.5" or just "7.5"
        match = re.search(r"\b([0-9](?:\.[0-9])?|10(?:\.0)?)\b", response)
        if match:
            return float(match.group(1))

        # Default mid-score if parsing fails
        return 5.0

    def score_all(self, papers: List[Dict]) -> List[Dict]:
        """Score all papers and attach relevance_score + critique to each."""
        for i, paper in enumerate(papers, 1):
            title_short = paper.get("title", "Unknown")[:55]
            print(f"   Scoring [{i}/{len(papers)}]: {title_short}...")
            paper["relevance_score"] = self.score(paper)

        # Sort by score descending
        papers.sort(key=lambda p: p.get("relevance_score", 0), reverse=True)
        return papers

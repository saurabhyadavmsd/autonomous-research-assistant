"""
agents/report_agent.py
Assembles all summaries into a coherent, well-structured research report.
"""

from typing import List, Dict
from langchain.chat_models import ChatOpenAI
from langchain.chains import LLMChain
from langchain.prompts import ChatPromptTemplate

from utils.prompts import REPORT_PROMPT
from tools.citation_tool import CitationTool
from config import Config


class ReportAgent:
    """
    Generates the final research report by:
    1. Identifying common themes across summaries
    2. Writing a narrative synthesis
    3. Adding structured sections (intro, methods, findings, gaps, conclusion)
    4. Appending formatted citations
    """

    def __init__(self, llm: ChatOpenAI, topic: str):
        self.llm = llm
        self.topic = topic
        self.citation_tool = CitationTool()
        self.chain = LLMChain(
            llm=self.llm,
            prompt=ChatPromptTemplate.from_template(REPORT_PROMPT),
        )

    def _build_summaries_block(self, papers: List[Dict]) -> str:
        """Format all summaries into a numbered block for the prompt."""
        blocks = []
        for i, paper in enumerate(papers, 1):
            score = paper.get("relevance_score", "N/A")
            blocks.append(
                f"[{i}] **{paper.get('title', 'Unknown')}**\n"
                f"Authors: {paper.get('authors', 'Unknown')}\n"
                f"Published: {paper.get('published', 'N/A')}\n"
                f"Relevance Score: {score}/10\n"
                f"Summary:\n{paper.get('summary', 'No summary.')}\n"
            )
        return "\n---\n".join(blocks)

    def generate(self, papers: List[Dict]) -> str:
        """Generate and return the full report as a Markdown string."""
        summaries_block = self._build_summaries_block(papers)
        citations = self.citation_tool.format_all(papers, style="APA")

        report_body = self.chain.run(
            topic=self.topic,
            paper_count=len(papers),
            summaries=summaries_block,
        )

        # Append citations section
        full_report = (
            f"{report_body.strip()}\n\n"
            f"---\n\n"
            f"## References\n\n"
            f"{citations}"
        )

        return full_report

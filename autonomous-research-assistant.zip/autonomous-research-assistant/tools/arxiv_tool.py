"""
tools/arxiv_tool.py
Wraps the arxiv Python library to search for academic papers.
"""

from typing import List, Dict, Any
import arxiv
from config import Config


class ArxivSearchTool:
    """
    Searches arXiv for papers matching a query.
    Returns structured paper dicts ready for the pipeline.
    """

    def __init__(self, max_results: int = Config.MAX_PAPERS):
        self.max_results = max_results

    def search(self, query: str) -> List[Dict[str, Any]]:
        """
        Search arXiv and return a list of paper metadata dicts.

        Args:
            query: Natural language or keyword search string

        Returns:
            List of dicts with: title, authors, abstract, url, published, source
        """
        search = arxiv.Search(
            query=query,
            max_results=self.max_results,
            sort_by=arxiv.SortCriterion.Relevance,
        )

        papers = []
        for result in search.results():
            papers.append({
                "title": result.title,
                "authors": ", ".join(a.name for a in result.authors),
                "abstract": result.summary,
                "url": result.entry_id,
                "pdf_url": result.pdf_url,
                "published": result.published.strftime("%Y-%m-%d") if result.published else "N/A",
                "source": "arXiv",
                "categories": result.categories,
            })

        return papers

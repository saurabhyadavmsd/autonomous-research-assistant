"""
tools/web_search.py
Wraps SerpAPI for supplemental web search when arXiv results are sparse.
"""

from typing import List, Dict, Any, Optional
import os

try:
    from serpapi import GoogleSearch
    SERPAPI_AVAILABLE = True
except ImportError:
    SERPAPI_AVAILABLE = False

from config import Config


class WebSearchTool:
    """
    Uses SerpAPI to search Google Scholar / general web for papers.
    Only used when arXiv returns insufficient results.
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or Config.SERPAPI_KEY

    def search(self, query: str, num_results: int = 10) -> List[Dict[str, Any]]:
        """
        Search the web for papers and return structured results.

        Args:
            query: Search query string
            num_results: Number of results to return

        Returns:
            List of paper dicts (may lack full abstracts)
        """
        if not SERPAPI_AVAILABLE:
            print("   [WebSearch] serpapi not installed. Run: pip install google-search-results")
            return []

        if not self.api_key:
            print("   [WebSearch] SERPAPI_KEY not set. Skipping web search.")
            return []

        params = {
            "engine": "google_scholar",
            "q": query,
            "num": num_results,
            "api_key": self.api_key,
        }

        results = []
        try:
            search = GoogleSearch(params)
            data = search.get_dict()
            organic = data.get("organic_results", [])

            for item in organic:
                results.append({
                    "title": item.get("title", "Unknown"),
                    "authors": self._extract_authors(item),
                    "abstract": item.get("snippet", ""),
                    "url": item.get("link", ""),
                    "published": item.get("publication_info", {}).get("summary", "N/A"),
                    "source": "Google Scholar",
                })
        except Exception as e:
            print(f"   [WebSearch] Error: {e}")

        return results

    def _extract_authors(self, item: dict) -> str:
        pub_info = item.get("publication_info", {})
        authors = pub_info.get("authors", [])
        if authors:
            return ", ".join(a.get("name", "") for a in authors)
        return "Unknown"

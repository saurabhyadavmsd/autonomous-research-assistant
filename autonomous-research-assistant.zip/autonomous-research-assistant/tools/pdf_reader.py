"""
tools/pdf_reader.py
Downloads and extracts text from PDF URLs using PyMuPDF.
"""

import io
import re
import requests
import fitz  # PyMuPDF
from typing import Optional


class PDFReaderTool:
    """
    Downloads a PDF from a URL and extracts its text content.
    Used by the Summarizer to get full paper text (not just abstract).
    """

    TIMEOUT = 30  # seconds
    MAX_PAGES = 15  # Limit pages to avoid huge token counts

    def read_from_url(self, url: str) -> Optional[str]:
        """
        Download a PDF and return extracted text.

        Args:
            url: Direct URL to PDF file

        Returns:
            Extracted text string, or None if download/parse fails
        """
        try:
            response = requests.get(url, timeout=self.TIMEOUT)
            response.raise_for_status()
            return self._extract_text(response.content)
        except requests.RequestException as e:
            print(f"   [PDFReader] Failed to download {url}: {e}")
            return None

    def _extract_text(self, pdf_bytes: bytes) -> str:
        """Extract text from raw PDF bytes using PyMuPDF."""
        text_parts = []
        try:
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
            pages_to_read = min(len(doc), self.MAX_PAGES)
            for page_num in range(pages_to_read):
                page = doc.load_page(page_num)
                text_parts.append(page.get_text())
            doc.close()
        except Exception as e:
            print(f"   [PDFReader] Parse error: {e}")
            return ""

        full_text = "\n".join(text_parts)
        # Basic cleanup: remove excessive whitespace
        full_text = re.sub(r"\n{3,}", "\n\n", full_text)
        full_text = re.sub(r" {2,}", " ", full_text)
        return full_text.strip()

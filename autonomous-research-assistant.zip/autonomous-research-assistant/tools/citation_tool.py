"""
tools/citation_tool.py
Formats paper metadata into APA or MLA citation strings.
"""

from typing import List, Dict


class CitationTool:
    """Formats paper metadata into citation strings."""

    def format_apa(self, paper: dict) -> str:
        """
        Format a single paper as an APA citation.
        Example: Smith, J., & Doe, A. (2023). Title of paper. arXiv. https://...
        """
        authors = paper.get("authors", "Unknown Author")
        year = self._extract_year(paper.get("published", "n.d."))
        title = paper.get("title", "Untitled")
        source = paper.get("source", "")
        url = paper.get("url", "")

        # Format author list: "Last, F., & Last, F."
        formatted_authors = self._format_author_list_apa(authors)
        citation = f"{formatted_authors} ({year}). {title}. *{source}*."
        if url:
            citation += f" {url}"
        return citation

    def format_mla(self, paper: dict) -> str:
        """Format a single paper as an MLA citation."""
        authors = paper.get("authors", "Unknown Author")
        title = paper.get("title", "Untitled")
        source = paper.get("source", "")
        year = self._extract_year(paper.get("published", "n.d."))
        url = paper.get("url", "")

        citation = f'{authors}. "{title}." *{source}*, {year}.'
        if url:
            citation += f" {url}."
        return citation

    def format_all(self, papers: List[Dict], style: str = "APA") -> str:
        """
        Format all papers into a numbered reference list.

        Args:
            papers: List of paper dicts
            style: "APA" or "MLA"

        Returns:
            Multi-line string with numbered citations
        """
        lines = []
        for i, paper in enumerate(papers, 1):
            if style.upper() == "MLA":
                citation = self.format_mla(paper)
            else:
                citation = self.format_apa(paper)
            lines.append(f"{i}. {citation}")
        return "\n\n".join(lines)

    def _extract_year(self, published: str) -> str:
        """Extract 4-digit year from published string."""
        import re
        match = re.search(r"\b(19|20)\d{2}\b", published)
        return match.group(0) if match else "n.d."

    def _format_author_list_apa(self, authors_str: str) -> str:
        """
        Convert 'First Last, First Last' to APA format 'Last, F., & Last, F.'
        Simple heuristic — handles common cases.
        """
        authors = [a.strip() for a in authors_str.split(",")]
        if len(authors) == 1:
            return authors[0]
        if len(authors) == 2:
            return f"{authors[0]}, & {authors[1]}"
        return f"{authors[0]}, {authors[1]}, & {authors[2]}" + (
            " et al." if len(authors) > 3 else ""
        )

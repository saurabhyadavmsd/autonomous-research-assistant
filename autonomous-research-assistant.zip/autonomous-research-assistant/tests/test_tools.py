"""
tests/test_tools.py
Unit tests for tool classes.
"""

import pytest
from unittest.mock import patch, MagicMock


# ─── CitationTool ─────────────────────────────────────────────────────────────

class TestCitationTool:
    def setup_method(self):
        from tools.citation_tool import CitationTool
        self.tool = CitationTool()

    def test_format_apa_basic(self):
        paper = {
            "title": "Attention Is All You Need",
            "authors": "Vaswani, A., Shazeer, N.",
            "published": "2017-06-12",
            "source": "arXiv",
            "url": "https://arxiv.org/abs/1706.03762",
        }
        citation = self.tool.format_apa(paper)
        assert "2017" in citation
        assert "Attention Is All You Need" in citation
        assert "arXiv" in citation

    def test_format_all_returns_numbered_list(self):
        papers = [
            {"title": "Paper A", "authors": "Doe, J.", "published": "2020", "source": "arXiv", "url": ""},
            {"title": "Paper B", "authors": "Smith, A.", "published": "2021", "source": "arXiv", "url": ""},
        ]
        result = self.tool.format_all(papers, style="APA")
        assert "1." in result
        assert "2." in result

    def test_extract_year_from_date(self):
        assert self.tool._extract_year("2023-04-15") == "2023"
        assert self.tool._extract_year("Published: 2019") == "2019"
        assert self.tool._extract_year("no year here") == "n.d."


# ─── PDFReaderTool ────────────────────────────────────────────────────────────

class TestPDFReaderTool:
    def test_returns_none_on_bad_url(self):
        from tools.pdf_reader import PDFReaderTool
        tool = PDFReaderTool()

        with patch("tools.pdf_reader.requests.get") as mock_get:
            mock_get.side_effect = Exception("Connection refused")
            result = tool.read_from_url("http://bad-url.example/paper.pdf")
            assert result is None


# ─── ArxivTool ────────────────────────────────────────────────────────────────

class TestArxivSearchTool:
    def test_search_returns_list(self):
        from tools.arxiv_tool import ArxivSearchTool

        tool = ArxivSearchTool(max_results=3)

        mock_result = MagicMock()
        mock_result.title = "Test Paper"
        mock_result.authors = [MagicMock(name="John Smith")]
        mock_result.summary = "Abstract text"
        mock_result.entry_id = "http://arxiv.org/abs/2301.00001"
        mock_result.pdf_url = "http://arxiv.org/pdf/2301.00001"
        mock_result.published.strftime.return_value = "2023-01-01"
        mock_result.categories = ["cs.AI"]

        with patch("tools.arxiv_tool.arxiv.Search") as mock_search:
            mock_search.return_value.results.return_value = [mock_result]
            papers = tool.search("language models")

        assert len(papers) == 1
        assert papers[0]["title"] == "Test Paper"
        assert papers[0]["source"] == "arXiv"

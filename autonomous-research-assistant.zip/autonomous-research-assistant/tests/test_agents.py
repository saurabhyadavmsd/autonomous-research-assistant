"""
tests/test_agents.py
Unit tests for all agent classes (mocked LLM calls).
"""

import pytest
from unittest.mock import MagicMock, patch


# ─── SearchAgent ─────────────────────────────────────────────────────────────

class TestSearchAgent:
    @patch("agents.search_agent.ArxivSearchTool")
    def test_search_returns_papers(self, mock_arxiv):
        from agents.search_agent import SearchAgent

        mock_papers = [
            {"title": "Paper A", "abstract": "Abstract A", "url": "http://arxiv.org/1", "source": "arXiv"},
            {"title": "Paper B", "abstract": "Abstract B", "url": "http://arxiv.org/2", "source": "arXiv"},
        ]
        mock_arxiv.return_value.search.return_value = mock_papers

        agent = SearchAgent(llm=MagicMock(), max_results=5)
        results = agent.search("transformer models")

        assert len(results) == 2
        assert results[0]["title"] == "Paper A"

    @patch("agents.search_agent.ArxivSearchTool")
    def test_search_deduplicates(self, mock_arxiv):
        from agents.search_agent import SearchAgent

        mock_papers = [
            {"title": "Same Paper", "abstract": "...", "url": "http://a", "source": "arXiv"},
            {"title": "Same Paper", "abstract": "...", "url": "http://b", "source": "arXiv"},
        ]
        mock_arxiv.return_value.search.return_value = mock_papers

        agent = SearchAgent(llm=MagicMock(), max_results=5)
        results = agent.search("some topic")

        assert len(results) == 1


# ─── SummarizerAgent ─────────────────────────────────────────────────────────

class TestSummarizerAgent:
    def test_summarize_returns_string(self):
        from agents.summarizer_agent import SummarizerAgent

        mock_llm = MagicMock()
        agent = SummarizerAgent(llm=mock_llm)
        agent.chain = MagicMock()
        agent.chain.run.return_value = "This is a summary."

        paper = {"title": "Test Paper", "abstract": "Some content here."}
        result = agent.summarize(paper)

        assert isinstance(result, str)
        assert len(result) > 0

    def test_summarize_truncates_long_text(self):
        from agents.summarizer_agent import SummarizerAgent

        mock_llm = MagicMock()
        agent = SummarizerAgent(llm=mock_llm)
        agent.chain = MagicMock()
        agent.chain.run.return_value = "Summary."

        # Create text > 3000 words
        long_text = "word " * 5000
        paper = {"title": "Long Paper", "abstract": long_text}
        agent.summarize(paper)

        # Ensure chain was called (text was processed)
        agent.chain.run.assert_called_once()


# ─── CriticAgent ─────────────────────────────────────────────────────────────

class TestCriticAgent:
    def test_score_parses_float(self):
        from agents.critic_agent import CriticAgent

        mock_llm = MagicMock()
        agent = CriticAgent(llm=mock_llm, topic="AI research")
        agent.chain = MagicMock()
        agent.chain.run.return_value = "Score: 8.5 — highly relevant."

        paper = {"title": "Good Paper", "summary": "Great work on AI."}
        score = agent.score(paper)

        assert score == 8.5

    def test_score_all_sorts_descending(self):
        from agents.critic_agent import CriticAgent

        mock_llm = MagicMock()
        agent = CriticAgent(llm=mock_llm, topic="AI")
        agent.chain = MagicMock()
        agent.chain.run.side_effect = ["3.0", "9.0", "6.0"]

        papers = [
            {"title": "Low", "summary": "..."},
            {"title": "High", "summary": "..."},
            {"title": "Mid", "summary": "..."},
        ]
        scored = agent.score_all(papers)

        scores = [p["relevance_score"] for p in scored]
        assert scores == sorted(scores, reverse=True)


# ─── ReportAgent ─────────────────────────────────────────────────────────────

class TestReportAgent:
    def test_generate_returns_markdown(self):
        from agents.report_agent import ReportAgent

        mock_llm = MagicMock()
        agent = ReportAgent(llm=mock_llm, topic="Test Topic")
        agent.chain = MagicMock()
        agent.chain.run.return_value = "# Report\n\nSome content here."

        papers = [
            {
                "title": "Paper 1",
                "authors": "Smith, J.",
                "published": "2023-01-01",
                "url": "http://example.com",
                "source": "arXiv",
                "summary": "A great paper.",
                "relevance_score": 8.0,
            }
        ]

        report = agent.generate(papers)

        assert "# Report" in report
        assert "References" in report

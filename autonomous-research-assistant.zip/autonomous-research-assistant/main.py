"""
Autonomous Research Assistant — Entry Point
Usage: python main.py --topic "Your Research Topic" --max_papers 10
"""

import argparse
import os
from agents.orchestrator import OrchestratorAgent
from utils.report_builder import ReportBuilder
from config import Config


def parse_args():
    parser = argparse.ArgumentParser(
        description="Autonomous Research Assistant using LangChain Agents"
    )
    parser.add_argument(
        "--topic", type=str, required=True,
        help="Research topic to investigate"
    )
    parser.add_argument(
        "--max_papers", type=int, default=Config.MAX_PAPERS,
        help="Maximum number of papers to retrieve"
    )
    parser.add_argument(
        "--format", type=str, default=Config.REPORT_FORMAT,
        choices=["md", "pdf"],
        help="Output report format"
    )
    parser.add_argument(
        "--output_dir", type=str, default="outputs",
        help="Directory to save the report"
    )
    return parser.parse_args()


def main():
    args = parse_args()

    print(f"\n{'='*60}")
    print(f"  🤖 Autonomous Research Assistant")
    print(f"{'='*60}")
    print(f"  Topic      : {args.topic}")
    print(f"  Max Papers : {args.max_papers}")
    print(f"  Format     : {args.format}")
    print(f"{'='*60}\n")

    # Validate API keys
    if not os.getenv("OPENAI_API_KEY"):
        raise EnvironmentError(
            "OPENAI_API_KEY not set. Please add it to your .env file."
        )

    # Initialize and run orchestrator
    orchestrator = OrchestratorAgent(
        topic=args.topic,
        max_papers=args.max_papers,
    )

    print("🔍 Step 1/4: Searching for relevant papers...")
    papers = orchestrator.run_search()
    print(f"   ✓ Found {len(papers)} papers\n")

    print("📄 Step 2/4: Summarizing papers...")
    summaries = orchestrator.run_summarization(papers)
    print(f"   ✓ Summarized {len(summaries)} papers\n")

    print("🔬 Step 3/4: Critiquing and filtering results...")
    filtered = orchestrator.run_critique(summaries)
    print(f"   ✓ {len(filtered)} papers passed quality filter\n")

    print("📝 Step 4/4: Generating research report...")
    report_content = orchestrator.run_report_generation(filtered)

    # Save the report
    os.makedirs(args.output_dir, exist_ok=True)
    builder = ReportBuilder(topic=args.topic, output_dir=args.output_dir)
    output_path = builder.save(report_content, fmt=args.format)

    print(f"\n{'='*60}")
    print(f"  ✅ Report saved to: {output_path}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
